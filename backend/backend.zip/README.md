# Flatmate Marketplace Backend

Clean, minimal, and properly typed backend foundation for the Flatmate Marketplace Platform built with Node.js, Express, TypeScript, MongoDB, AWS S3, and Nodemailer.

## Tech Stack

* Node.js
* Express.js
* TypeScript
* MongoDB & Mongoose
* AWS S3 (@aws-sdk/client-s3)
* Nodemailer
* dotenv & cors
* tsx

## Project Structure

```text
backend/
├── src/
│   ├── config/
│   │   ├── aws.ts
│   │   ├── db.ts
│   │   ├── email.ts
│   │   └── env.ts
│   ├── controllers/
│   │   ├── admin.controller.ts
│   │   ├── otp.controller.ts
│   │   ├── profile.controller.ts
│   │   ├── session.controller.ts
│   │   └── user.controller.ts
│   ├── models/
│   │   ├── admin.model.ts
│   │   ├── adminSession.model.ts
│   │   ├── otp.model.ts
│   │   ├── user.model.ts
│   │   ├── userProfile.model.ts
│   │   └── userSession.model.ts
│   ├── routes/
│   │   ├── admin.routes.ts
│   │   ├── index.ts
│   │   ├── otp.routes.ts
│   │   ├── profile.routes.ts
│   │   ├── session.routes.ts
│   │   └── user.routes.ts
│   ├── services/
│   │   ├── aws/
│   │   └── email/
│   ├── middlewares/
│   ├── utils/
│   ├── app.ts
│   └── server.ts
├── .env
├── .env.example
├── package.json
└── README.md
```

## Environment Variables & Configuration

Copy `.env.example` to `.env` and fill in required values:

```env
# Application Mode (development | production | test)
NODE_MODE=development
PORT=5000
# Client Application URLs (comma-separated for CORS)
CLIENT_URLS=http://localhost:3000,http://localhost:3001

# MongoDB Configuration (Environment-based database name selection)
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net
MONGODB_DEVE_NAME=development
MONGODB_PROD_NAME=production
MONGODB_TEST_NAME=test

# AWS S3 Storage Configuration
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_S3_BUCKET=
AWS_CLOUDFRONT_URL=

# SMTP / Email Service Configuration
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=

# MSG91 OTP Verification Service
MSG91_AUTH_KEY=your_msg91_auth_key
MSG91_SENDER_ID=your_msg91_sender_id
MSG91_OTP_TEMPLATE_ID=your_msg91_otp_template_id

# JWT Authentication Configuration
JWT_ACCESS_SECRET=
JWT_REFRESH_SECRET=
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=30d

# Initial Super Admin Seed Credentials
SUPER_ADMIN_NAME=
SUPER_ADMIN_EMAIL=
SUPER_ADMIN_PASSWORD=
```

### Environment-Based Database Selection

A single `MONGODB_URI` connection string is used across environments. Mongoose connects using database names selected by `NODE_MODE`:
* `development` → Uses `MONGODB_DEVE_NAME` (default: `development`)
* `production` → Uses `MONGODB_PROD_NAME` (default: `production`)
* `test` → Uses `MONGODB_TEST_NAME` (default: `test`)

## Installation

```bash
npm install
```

## Development

Run the development server with live reload:

```bash
npm run dev
```

## Seed Initial Super Admin

```bash
npm run seed:super-admin
```

## Type Checking

```bash
npm run typecheck
```

## Build

```bash
npm run build
```

## Production

```bash
npm start
```
